#!/bin/bash
sudo chown -R www-data:www-data /var/www/html/
sudo chmod -R 766 /var/www/html/